<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>

<h1>The table element</h1>

<table>

<tr>
    <th width="10%">Id</th>
    <th width="40%">Class</th>
    <th width="40%">First name</th>
    <th width="40%">Last name</th>
    <th width="40%">Gender</th>
    <th width="40%">DOB</th>
    <th width="40%">City</th>
    <th width="40%">Taluka</th>
    <th width="40%">District</th>
    <th width="40%">State</th>
    <th width="40%">Country</th>
    <th width="40%">Nationalty</th>
    <th width="40%">Religion</th>
    <th width="40%">Caste</th>
    <th width="40%">Category</th>
    <th width="40%">Mohter Tongue</th>
    <th width="40%">Languages</th>
    <th width="40%">Fathers Fname</th>
    <th width="40%">Fatherss Mname</th>
    <th width="40%">Fathers Lname</th>
    <th width="40%">Fathers Qualification</th>
    <th width="40%">Fathers Occupation</th>
    <th width="40%">Mothers Fname</th>
    <th width="40%">Mothers Mname</th>
    <th width="40%">Mothers Lname</th>
    <th width="40%">Mothers Qualification</th>
    <th width="40%">Mothers Occupation</th>
    <th width="40%">Income</th>
    <th width="40%">Address/th>
    <th width="40%">Email</th>
    <th width="40%">Aadhar</th>
    <th width="40%">Distance</th>
    <th width="40%">Landmark</th>
    <th width="40%">Whatsapp No</th>
    <th width="40%">Telephone No</th>
    <th width="40%">Permanent Address</th>
    <th width="40%">Brothers/Sisters</th>
    <th width="40%">File</th>
    <th width="10%">Delete</th>
    </tr>
</table>

</body>
</html>
