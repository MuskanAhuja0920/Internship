<?php
define('EMAIL','webapp.services.ma@gmail.com');
define('PASSWORD','9450340908');
$dbhost='localhost';
$dbuser='root';
$dbpass='';
$dbname='userverification';
?>